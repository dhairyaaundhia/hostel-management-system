const Mess_bill_per_day = 300;

module.exports = {
    Mess_bill_per_day
}