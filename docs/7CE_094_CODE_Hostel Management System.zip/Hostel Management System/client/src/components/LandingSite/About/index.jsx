import { About } from "./About"

export default function AboutPage() {
  return (
    <About />
  )
}
