import { HeroSection } from "./HeroSection";

export default function index() {
  return (
    <>
      <HeroSection />
    </>
  );
}
